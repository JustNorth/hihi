# movies-streaming-dan-admin
Seperti indoxxi sebagai tempat sarana live streaming atau download film
Aplikasi ini hanya dibuat dengan PHP Native dan template Admin LTE

Cara menggunakan: 
1. Ekstrak file ini
2. Buat database dengan nama: resensi_film_andri
3. Import database resensi_film_andri.sql
4. Jalankan localhost/resensi_film_andri
5. Selesai

Untuk halaman mengakses Admin, ada dibagian footer pada link admin room's

❥ Username: andri123

❥ Password: 12345

Fitur:
1. Live Search
2. Administrator Management
3. Comments
4. dan banyak lagi
